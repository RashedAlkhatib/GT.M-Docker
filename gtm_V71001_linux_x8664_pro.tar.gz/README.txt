All software in this package is part of FIS GT.M (http://fis-gtm.com) which is Copyright 2023 Fidelity Information
Services, Inc., and provided to you under the terms of a license. If there is a COPYING file included in this package,
it contains the terms of the license under which the package is provided to you. If there is not a COPYING file in the
package, you must ensure that your use of FIS GT.M complies with the license under which it is provided. If you are
unsure as to the terms of your license, please consult with the entity that provided you with the package.
