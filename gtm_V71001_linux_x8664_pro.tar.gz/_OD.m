;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;								;
; Copyright (c) 1987-2019 Fidelity National Information		;
; Services, Inc. and/or its subsidiaries. All rights reserved.	;
;								;
;	This source code contains the intellectual property	;
;	of its copyright holder(s), and is made available	;
;	under a license.  If you do not know the terms of	;
;	the license, please stop and do not read further.	;
;								;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
%OD	;GT.M %OD utility - octal to decimal conversion program
	;invoke at INT with %OD in octal to return %OD in decimal
	;invoke at FUNC as an extrinsic function
	;if you make heavy use of this routine, consider $ZCALL
	;
	set %OD=$$FUNC(%OD)
	quit
INT	read !,"Octal: ",%OD set %OD=$$FUNC(%OD)
	q
FUNC(o)
	quit:"0"[$get(o) 0
	quit:"-"=$extract(o) ""
	new c,d,l
	set d=0,l=$length(o)
	quit:(18<l) $$CONVERTBASE^%CONVBASEUTIL(o,8,10)
	for c=1:1:l set d=d*8+$extract(o,c)
	quit d
